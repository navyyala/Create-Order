# Deployment Guide — ZGPM_ORDER_CRE to ABAP BSP
**Date:** 2025-08-17  
**Target System (Development):** `http://sdctwd0024.ad.ponet:8000` — Client 100  
**Target System (Test/QAS):** `https://sdctwq0127.ad.ponet/` — Client 100  
**BSP Application:** `ZGPM_ORDER_CRE`  
**ABAP Package:** `ZPM`

---

## Prerequisites

| Requirement | Status |
|---|---|
| Node.js v18+ installed | ✅ (v24.18.0 detected) |
| npm packages installed (`npm install`) | ✅ |
| `ui5-deploy.yaml` configured | ✅ |
| ABAP user with `S_DEVELOP` + `S_TRANSPRT` auth | ⬜ Verify with Basis |
| Transport request number | ⬜ **REQUIRED — obtain from Basis/SAP GUI SE10** |
| RFC destination `local` configured in SAP system | ⬜ Verify |

---

## Step 1 — Update `ui5-deploy.yaml` with Transport Request

Open [ui5-deploy.yaml](../../ui5-deploy.yaml) and fill in the transport request number:

```yaml
# ui5-deploy.yaml excerpt
deploy_mode: application
app:
  name: ZGPM_ORDER_CRE
  package: ZPM
  transport: <YOUR_TRANSPORT_REQUEST_NUMBER>   # e.g. ZPM K900123
```

> ⚠️ **Never commit the transport number to git.** Use an environment variable or `.env` file:
> ```yaml
> transport: ${TRANSPORT_REQUEST}
> ```

---

## Step 2 — Set Credentials (Secure)

**Do NOT store credentials in any file.** Use one of:

### Option A — Environment Variables (recommended)
```powershell
$env:UI5_DEPLOY_USER = "YOURUSERNAME"
$env:UI5_DEPLOY_PASSWORD = "YOURPASSWORD"
npx fiori deploy
```

### Option B — Interactive prompt
```powershell
npx fiori deploy
# Enter credentials when prompted
```

---

## Step 3 — Deploy to Development System (GWD)

```powershell
cd "d:\Nagamani\CMMS code\ZGPM_ORDER_CRE"

# Deploy using GWD (development) config
npx fiori deploy --config ui5-deploy.yaml
```

Expected output:
```
Deploying to http://sdctwd0024.ad.ponet:8000
Uploading file: webapp/manifest.json ✓
Uploading file: webapp/index.html ✓
...
Deployment complete. BSP application ZGPM_ORDER_CRE updated.
```

---

## Step 4 — Verify in SAP GUI

1. Open SAP GUI → Transaction `SE80`
2. Navigate: **BSP Applications → ZGPM_ORDER_CRE**
3. Verify all `webapp/` files are present with latest timestamps
4. Open Transaction `SE16` → Table `TRDIR` → check program `ZGPM_ORDER_CRE`

---

## Step 5 — Smoke Test in Development System

1. Open browser: `http://sdctwd0024.ad.ponet:8000/sap/bc/bsp/sap/zgpm_order_cre/index.html`
2. Run Module A, B, C, D test cases from [Regression Test Specification](02-Regression-Test-Specification.md)
3. Verify OData requests hit `ZGPM_CREATE_ORDER_SRV`

---

## Step 6 — Transport to QAS / Production

1. SAP GUI → `SE10` → open your transport request
2. Release the task → Release the request
3. SAP GUI on QAS → `STMS` → Import Queue
4. Import the transport request
5. Repeat Step 5 smoke test against QAS backend: `https://sdctwq0127.ad.ponet/`

---

## Rollback After Deployment

See [03-Rollback-Strategy.md](03-Rollback-Strategy.md) — Level 2 and Level 3.

---

## Known Limitations

| Limitation | Details |
|---|---|
| `ui5 build --all` fails | `@sapui5/distribution-metadata@1.71.84` not on npm. **Workaround**: `npx fiori deploy` uploads raw source files directly — no local build artifact required for ABAP BSP deploy. |
| Self-signed cert on QAS | `ignoreCertErrors: true` in `ui5-gwq.yaml` for local dev only; not needed in ABAP import flow. |
| npm audit: 30 dev-dep vulnerabilities | Not relevant to production ABAP deployment (dev dependencies are not deployed). |

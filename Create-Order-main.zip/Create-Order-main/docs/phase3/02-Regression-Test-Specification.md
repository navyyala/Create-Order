# Regression Test Specification — ZGPM_ORDER_CRE
**Date:** 2025-08-17  
**Application:** CMMS Work Order Creation (`PO_CREATEORDER`)  
**SAPUI5 Version:** 1.71.84 | **Theme:** sap_fiori_3  
**Backend GWQ (Test):** `https://sdctwq0127.ad.ponet/`

---

## 1. Test Scope

All functional areas of the application verified after Phase 2 migration.

---

## 2. Test Cases

### Module A — Navigation & Routing

| ID | Test Case | Steps | Expected | Status |
|---|---|---|---|---|
| A-01 | App loads at `/` | Navigate to `localhost:8082` | Master-Detail split layout renders; master list populated | 🔲 Pending |
| A-02 | Back navigation | Click Back in Detail view | Master panel visible, Detail resets | 🔲 Pending |
| A-03 | Phone mode layout | Resize to < 600px | Single-view mode: Master hidden, Detail full-width | 🔲 Pending |
| A-04 | FLP sandbox tile | Open `webapp/test/flpSandbox.html` via dev server | Tile `ZPMSEMORDERCREATE-DISPLAY_G` shown; click opens app | 🔲 Pending |
| A-05 | Not-found route | Navigate to `/#/invalidroute` | NotFound view displayed with go-home button | 🔲 Pending |

### Module B — Master List

| ID | Test Case | Steps | Expected | Status |
|---|---|---|---|---|
| B-01 | Work order list loads | Open app | `WorkOrderSet` OData call fires; list items rendered | 🔲 Pending |
| B-02 | Pull-to-refresh | Pull list down | `WorkOrderSet` re-fetched; list updated | 🔲 Pending |
| B-03 | Search by work order | Type in search field | List filtered client-side; matching orders shown | 🔲 Pending |
| B-04 | Barcode scan button | Click scan icon | Barcode scanner dialog opens | 🔲 Pending |
| B-05 | Cross-app: Manage orders | Click 'Manage' button | Navigation to `GPM_WORK_ORDER_MANAGE` semantic object | 🔲 Pending |
| B-06 | List item tap | Tap a work order | Detail view loaded with selected order data | 🔲 Pending |

### Module C — Create Order Form

| ID | Test Case | Steps | Expected | Status |
|---|---|---|---|---|
| C-01 | Open Create Order | Click '+' / Create Order button | Master panel hides (`hideMaster()` called); create-order form appears in Detail | 🔲 Pending |
| C-02 | Form required fields | Submit without filling fields | Validation messages shown on mandatory fields | 🔲 Pending |
| C-03 | Functional location value help | Click FL field | Value help dialog opens; FL list loaded from OData | 🔲 Pending |
| C-04 | Equipment value help | Click Equipment field | Value help dialog opens; equipment list loaded | 🔲 Pending |
| C-05 | Planner group change | Change Planner Group | Work Centre field filtered accordingly | 🔲 Pending |
| C-06 | Date field | Set planned start date | Date formatted correctly in OData call (`yyyy-MM-ddT00:00:00`) | 🔲 Pending |
| C-07 | Cancel order creation | Click Cancel | Confirm dialog shown; on Confirm → form closed, Master shown | 🔲 Pending |
| C-08 | Submit new work order | Fill all required fields; click Save | `WorkOrderSet` POST call fires; success message; list refreshed | 🔲 Pending |

### Module D — Activities / Operations Table

| ID | Test Case | Steps | Expected | Status |
|---|---|---|---|---|
| D-01 | Table renders empty | Open create form | Operations table visible with zero rows | 🔲 Pending |
| D-02 | Add new operation | Click '+' in operations table | Add/Edit dialog opens in Add mode | 🔲 Pending |
| D-03 | Dialog validation | Submit without Description | `ValueState.Error` shown on Description field | 🔲 Pending |
| D-04 | Save new operation | Fill Description; click Save | Row appears in table; item number auto-assigned | 🔲 Pending |
| D-05 | Edit existing operation | Click row; click Edit | Dialog opens in Edit mode; fields pre-populated with row data | 🔲 Pending |
| D-06 | Edit save operation | Modify Description; Save | Row updated in-place; `_itemsData` reflects change | 🔲 Pending |
| D-07 | Delete operation | Select row; click Delete | Row removed from table; `_itemsData` updated | 🔲 Pending |
| D-08 | Multiple operations | Add 3 operations | All three rows rendered; correct item numbers | 🔲 Pending |

### Module E — Canvas / Signature

| ID | Test Case | Steps | Expected | Status |
|---|---|---|---|---|
| E-01 | Canvas opens | Click signature/canvas button | Canvas fragment loads; drawing area visible | 🔲 Pending |
| E-02 | Draw on canvas | Mouse drag on canvas | Stroke appears; no duplicate event listeners | 🔲 Pending |
| E-03 | Clear canvas | Click Clear | Canvas cleared | 🔲 Pending |
| E-04 | Save canvas | Click Save | Image data URL stored in `_dataURL`; image control updated | 🔲 Pending |

### Module F — Photo Upload

| ID | Test Case | Steps | Expected | Status |
|---|---|---|---|---|
| F-01 | Upload photo | Select file via upload button | FileUploader sends POST to `PHOTOSet` | 🔲 Pending |
| F-02 | Upload error handling | Select invalid file type | Error message displayed | 🔲 Pending |

### Module G — Message Handling

| ID | Test Case | Steps | Expected | Status |
|---|---|---|---|---|
| G-01 | Success message | Successful order create | `sap.m.MessageToast` or `MessageBox` shown | 🔲 Pending |
| G-02 | OData error | Backend returns 4xx | Error message displayed via MessageBox.error | 🔲 Pending |
| G-03 | Network timeout | Disconnect network; retry action | Error message displayed; app does not freeze | 🔲 Pending |

---

## 3. Automated Test Coverage

| Test File | Framework | Coverage |
|---|---|---|
| `webapp/test/unit/unitTests.qunit.js` | QUnit | `_pad`, `_toODataDateTime`, manifest config |
| `webapp/test/integration/opaTests.qunit.js` | OPA5 | Search field, scan button, create-order button |

**Automated coverage is skeleton-level (~15%).** Full automated coverage recommended before production.

---

## 4. Test Execution Environment

| Parameter | Value |
|---|---|
| Dev Server | `npx fiori run --open test/flpSandbox.html` |
| Backend | `https://sdctwq0127.ad.ponet/` (GWQ — test system) |
| Self-Signed Cert | Bypassed via `ignoreCertErrors: true` in `ui5-gwq.yaml` |
| UI5 Runtime | CDN: `https://sapui5.hana.ondemand.com/1.71.84` via proxy |
| Theme | `sap_fiori_3` |

---

## 5. Known Defects / Out-of-Scope Items

| Item | Notes |
|---|---|
| `ui5 build --all` fails | SAPUI5 1.71.84 not on npm registry — not needed for ABAP BSP deploy |
| Old `view/` folder files | Show VS Code parser warnings — not loaded at runtime |
| npm audit: 30 vulns | All in dev dependencies (fiori-tools-proxy etc.); 0 prod vulnerabilities |

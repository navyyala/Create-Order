# Rollback Strategy — ZGPM_ORDER_CRE Migration
**Date:** 2025-08-17  
**Migration Baseline Tag:** `v2.0.0-migration-complete` (commit `f6447c1`)  
**Pre-Migration Baseline Tag/Commit:** `84cc21e` (Initial commit — original Web IDE source)

---

## 1. Rollback Levels

Three independent rollback levels can be executed separately or in combination.

### Level 1 — Git Source Rollback (Local/Remote)

**When to use:** Code-level regression after Phase 2 commits; testing reveals a critical defect.

**Original Web IDE source commit:** `84cc21e`  
**Migration complete tag:** `v2.0.0-migration-complete` (`f6447c1`)

```bash
# Option A: Revert working tree to original Web IDE source
cd "d:\Nagamani\CMMS code"
git checkout 84cc21e -- .

# Option B: Create a rollback branch from the original commit
git checkout -b rollback/webide-original 84cc21e

# Option C: Hard reset to original (DESTRUCTIVE — loses migration commits)
# Only do this if you are absolutely sure:
# git reset --hard 84cc21e
```

**To restore migration work after rollback investigation:**
```bash
git checkout v2.0.0-migration-complete
```

---

### Level 2 — ABAP Transport Rollback

**When to use:** Migration has been transported to ABAP production system (GWD) and a defect is found post-go-live.

**Steps:**
1. Open SAP GUI → Transaction `SE10` (Transport Organiser)
2. Locate the transport request containing `ZGPM_ORDER_CRE`
3. If the request was NOT yet released:
   - Delete object `ZGPM_ORDER_CRE` from the task
4. If the request WAS released and imported to production:
   - Create a new correction transport
   - Reimport the previous (known-good) transport request via `STMS` → Import Queue
   - Import the previous version's transport in the correct system landscape order (DEV → QAS → PRD)
5. Verify BSP application in Transaction `SE80` → BSP Applications → `ZGPM_ORDER_CRE`

---

### Level 3 — BSP Application Restore (Emergency)

**When to use:** Production issue requiring immediate rollback without a transport available.

**Steps:**
1. SAP GUI → `SE80` → BSP Applications → `ZGPM_ORDER_CRE`
2. Manually revert changed objects:
   - `Component.js`
   - `MyRouter.js`
   - `manifest.json`
   - `controller/Detail.controller.js`
   - `controller/Master.controller.js`
3. Use the previous version's source from git tag `84cc21e`:
   ```bash
   git show 84cc21e:ZGPM_ORDER_CRE/view/Detail.controller.js
   ```
4. Copy content into the SE80 editor and activate

---

## 2. Rollback Decision Matrix

| Trigger | Level | Estimated Time |
|---|---|---|
| Unit/OPA test failure in dev environment | Level 1 | 5 minutes |
| Integration test failure in QAS | Level 1 + 2 (new transport) | 30 minutes |
| Production defect (minor) | Level 2 (previous transport) | 60 minutes |
| Production defect (critical, no transport) | Level 3 (BSP manual edit) | 2–4 hours |

---

## 3. Rollback Communication Template

> **[ROLLBACK NOTIFICATION]**  
> System: ZGPM_ORDER_CRE (CMMS Work Order Creation)  
> Date: [DATE]  
> Reason: [DESCRIBE DEFECT]  
> Action: Rollback to [Level 1/2/3] — [describe action taken]  
> ETA for Resolution: [TIME]  
> Contact: [OWNER]

---

## 4. Verification Checklist After Rollback

- [ ] Master list loads correctly at `/` 
- [ ] Work order tile appears in FLP (`ZPMSEMORDERCREATE-DISPLAY_G`)
- [ ] Create Order form opens; master panel hides
- [ ] Operations table: add/edit/delete item works
- [ ] OData calls reach backend `sdctwd0024.ad.ponet:8000` client 100
- [ ] i18n language switching works
- [ ] No console errors in browser DevTools
